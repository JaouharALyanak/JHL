<?php

/**
 * JHL Business OS — Formulaire de participation au programme de test
 * Réutilise la configuration SMTP Hostinger de contact.php
 */

// Headers CORS / JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Accept');

// OPTIONS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Vérifier méthode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

// ============================================
// RÉCUPÉRATION DES DONNÉES
// Supporte multipart/form-data (FormData) ET application/json
// ============================================
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';

// Lire php://input en priorité si présent, sinon $_POST
$rawInput = file_get_contents('php://input');
$jsonDecoded = !empty($rawInput) ? json_decode($rawInput, true) : null;

if (is_array($jsonDecoded)) {
    $data = $jsonDecoded;
} else {
    $data = $_POST;
}

// ============================================
// PROTECTION ANTI-SPAM (honeypot)
// ============================================
if (!empty($data['_hp_business_os'])) {
    // Faux succès pour les bots
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Demande enregistrée.']);
    exit;
}

// ============================================
// VALIDATION CÔTÉ SERVEUR (Frictionless pour Ads)
// Seuls le Nom, l'Email et le Consentement sont strictement requis
// Les autres champs sont optionnels pour maximiser les conversions Ads
// ============================================
$errors = [];

// Nom et prénom (requis)
$nom = trim($data['bos_nom'] ?? '');
if (strlen($nom) < 2) {
    $errors['bos_nom'] = 'Veuillez indiquer votre nom et prénom.';
}

// Email (requis)
$email = trim($data['bos_email'] ?? '');
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['bos_email'] = 'Veuillez entrer une adresse e-mail valide.';
}

// Consentement (requis mais tolérant aux formats navigateur: oui, on, 1, true)
$consentVal = strtolower(trim((string)($data['bos_consentement'] ?? 'oui')));
if (!in_array($consentVal, ['oui', 'on', '1', 'true', 'yes'], true)) {
    $errors['bos_consentement'] = 'Votre consentement est requis.';
}

// Retourner les erreurs s'il y en a
if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Champs qualificatifs optionnels (sauvegardés s'ils sont fournis)
$entreprise             = trim($data['bos_entreprise']             ?? 'Non indiqué');
$whatsapp               = trim($data['bos_whatsapp']               ?? 'Non indiqué');
$ville                  = trim($data['bos_ville']                  ?? 'Non précisée');
$secteur                = trim($data['bos_secteur']                ?? 'Non précisé');
$tailleEquipe           = trim($data['bos_taille_equipe']          ?? 'Non précisée');
$volumeMensuel          = trim($data['bos_volume_mensuel']         ?? 'Non précisé');
$volumeIa               = trim($data['bos_volume_ia']              ?? 'Non précisé');
$plateformes            = trim($data['bos_plateformes']            ?? 'Non spécifié');
$fonctionsPrioritaires  = trim($data['bos_fonctions_prioritaires'] ?? 'Non spécifié');
$difficulte             = trim($data['bos_difficulte']             ?? 'Non précisée');
$budget                 = trim($data['bos_budget']                 ?? 'Non précisé');
$preference             = trim($data['bos_preference']             ?? $data['bos_participation'] ?? 'Démonstration privée & test pilote');
$participation          = $preference;

// ============================================
// SAUVEGARDE JSON (backup fiable)
// ============================================
$leadsFile = __DIR__ . '/business-os-leads.json';
$leads = [];

if (file_exists($leadsFile)) {
    $existing = file_get_contents($leadsFile);
    $leads = json_decode($existing, true) ?: [];
}

$newLead = [
    'id'                      => uniqid('bos_', true),
    'date'                    => date('Y-m-d H:i:s'),
    'nom'                     => $nom,
    'entreprise'              => $entreprise,
    'email'                   => $email,
    'whatsapp'                => $whatsapp,
    'ville'                   => $ville,
    'secteur'                 => $secteur,
    'taille_equipe'           => $tailleEquipe,
    'volume_mensuel'          => $volumeMensuel,
    'volume_ia'               => $volumeIa,
    'plateformes'             => $plateformes,
    'fonctions_prioritaires'  => $fonctionsPrioritaires,
    'difficulte'              => $difficulte,
    'budget'                  => $budget,
    'preference'              => $preference,
    'participation'           => $participation,
    'ip'                      => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
    'user_agent'              => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 150)
];

$leads[] = $newLead;
file_put_contents($leadsFile, json_encode($leads, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

// ============================================
// EMAIL HTML (même SMTP que contact.php)
// ============================================
$subject = '🚀 JHL Business OS — Nouvelle demande de test : ' . $nom;

$htmlMessage = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #1F2937; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 640px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .header { background: linear-gradient(135deg, #1E40AF 0%, #3B82F6 100%); color: white; padding: 28px 32px; }
        .header h2 { margin: 0; font-size: 20px; }
        .header p { margin: 6px 0 0; opacity: 0.85; font-size: 14px; }
        .badge { display: inline-block; background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; margin-bottom: 10px; }
        .content { padding: 28px 32px; }
        .section { margin-bottom: 24px; }
        .section-title { font-size: 13px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.06em; color: #6B7280; margin-bottom: 12px; border-bottom: 1px solid #E5E7EB; padding-bottom: 6px; }
        .field { display: flex; gap: 12px; margin-bottom: 10px; }
        .field-label { font-weight: bold; color: #1E40AF; min-width: 180px; font-size: 14px; }
        .field-value { color: #374151; font-size: 14px; flex: 1; }
        .difficulte-box { background: #F0F9FF; border-left: 4px solid #3B82F6; padding: 14px 16px; border-radius: 0 8px 8px 0; margin-top: 6px; font-size: 14px; color: #374151; white-space: pre-wrap; }
        .btn { display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #1E40AF, #3B82F6); color: white; text-decoration: none; border-radius: 8px; margin-top: 8px; font-size: 14px; font-weight: bold; }
        .footer { background: #F9FAFB; padding: 16px 32px; font-size: 12px; color: #9CA3AF; border-top: 1px solid #E5E7EB; }
        .participation-badge { display: inline-block; padding: 5px 14px; background: #DBEAFE; color: #1E40AF; border-radius: 20px; font-weight: bold; font-size: 13px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="badge">🚀 Nouveau prospect</div>
            <h2>JHL Business OS — Demande de test</h2>
            <p>Reçue le ' . date('d/m/Y à H:i') . ' • ID : ' . $newLead['id'] . '</p>
        </div>
        <div class="content">

            <!-- Coordonnées -->
            <div class="section">
                <div class="section-title">👤 Coordonnées</div>
                <div class="field"><span class="field-label">Nom et prénom</span><span class="field-value"><strong>' . htmlspecialchars($nom) . '</strong></span></div>
                <div class="field"><span class="field-label">Entreprise</span><span class="field-value">' . htmlspecialchars($entreprise) . '</span></div>
                <div class="field"><span class="field-label">E-mail</span><span class="field-value"><a href="mailto:' . htmlspecialchars($email) . '">' . htmlspecialchars($email) . '</a></span></div>
                <div class="field"><span class="field-label">WhatsApp</span><span class="field-value">' . htmlspecialchars($whatsapp) . '</span></div>
                <div class="field"><span class="field-label">Ville</span><span class="field-value">' . htmlspecialchars($ville) . '</span></div>
            </div>

            <!-- Activité -->
            <div class="section">
                <div class="section-title">🏢 Activité & Équipe</div>
                <div class="field"><span class="field-label">Secteur</span><span class="field-value">' . htmlspecialchars($secteur) . '</span></div>
                <div class="field"><span class="field-label">Taille équipe</span><span class="field-value">' . htmlspecialchars($tailleEquipe) . '</span></div>
                <div class="field"><span class="field-label">Demandes / mois</span><span class="field-value">' . htmlspecialchars($volumeMensuel) . '</span></div>
                <div class="field"><span class="field-label">Volume IA souhaité</span><span class="field-value">' . htmlspecialchars($volumeIa) . '</span></div>
                <div class="field"><span class="field-label">Plateformes souhaitées</span><span class="field-value">' . htmlspecialchars($plateformes) . '</span></div>
                <div class="field"><span class="field-label">Fonctions prioritaires</span><span class="field-value">' . htmlspecialchars($fonctionsPrioritaires) . '</span></div>
                <div class="field"><span class="field-label">Budget mensuel</span><span class="field-value">' . htmlspecialchars($budget) . '</span></div>
            </div>

            <!-- Difficulté -->
            <div class="section">
                <div class="section-title">💬 Principale difficulté</div>
                <div class="difficulte-box">' . nl2br(htmlspecialchars($difficulte)) . '</div>
            </div>

            <!-- Participation -->
            <div class="section">
                <div class="section-title">🎯 Type de participation</div>
                <span class="participation-badge">' . htmlspecialchars($participation) . '</span>
            </div>

            <a href="mailto:' . htmlspecialchars($email) . '?subject=RE: JHL Business OS - Votre demande de test" class="btn">
                ✉️ Répondre à ' . htmlspecialchars($nom) . '
            </a>
        </div>
        <div class="footer">
            Envoyé automatiquement depuis jhl.ma/business-os/ · IP: ' . htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? 'N/A') . '
        </div>
    </div>
</body>
</html>
';

// ============================================
// ENVOI SMTP (Hostinger SSL port 465) + Fallback mail()
// ============================================
$emailSent = false;
$emailError = null;
$smtpDebug = [];

try {
    $smtp_host      = 'smtp.hostinger.com';
    $smtp_port      = 465;
    $smtp_username  = 'smtp@jhl.ma';
    $smtp_password  = '8i*BV1ZxjI';
    $smtp_from      = 'smtp@jhl.ma';
    $smtp_from_name = 'JHL Business OS';
    $smtp_to        = 'contact@jhl.ma';

    $context = stream_context_create([
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true
        ]
    ]);

    $smtp = @stream_socket_client(
        "ssl://{$smtp_host}:{$smtp_port}",
        $errno,
        $errstr,
        15,
        STREAM_CLIENT_CONNECT,
        $context
    );

    if (!$smtp) {
        throw new Exception("Connexion SMTP impossible : {$errstr} ({$errno})");
    }

    // Lire banner
    $banner = fgets($smtp, 512);

    // Helper SMTP avec vérification des réponses
    $smtpSend = function ($command, $expectedCode = null) use ($smtp, &$smtpDebug) {
        fwrite($smtp, $command . "\r\n");
        $fullResponse = '';
        do {
            $line = fgets($smtp, 512);
            $fullResponse .= $line;
            $smtpDebug[] = trim($line);
        } while (isset($line[3]) && $line[3] === '-');

        if ($expectedCode !== null && substr($fullResponse, 0, 3) !== (string)$expectedCode) {
            throw new Exception("Erreur SMTP sur [{$command}] : " . trim($fullResponse));
        }
        return $fullResponse;
    };

    $smtpSend("EHLO jhl.ma", 250);
    $smtpSend("AUTH LOGIN", 334);
    $smtpSend(base64_encode($smtp_username), 334);
    $smtpSend(base64_encode($smtp_password), 235);
    $smtpSend("MAIL FROM: <{$smtp_from}>", 250);
    $smtpSend("RCPT TO: <{$smtp_to}>", 250);
    $smtpSend("DATA", 354);

    $mail  = "From: {$smtp_from_name} <{$smtp_to}>\r\n";
    $mail .= "To: <{$smtp_to}>\r\n";
    $mail .= "Reply-To: {$email}\r\n";
    $mail .= "Subject: {$subject}\r\n";
    $mail .= "MIME-Version: 1.0\r\n";
    $mail .= "Content-Type: text/html; charset=UTF-8\r\n";
    $mail .= "X-Priority: 1\r\n";
    $mail .= "\r\n";
    $mail .= $htmlMessage;
    $mail .= "\r\n.\r\n";

    fwrite($smtp, $mail);
    $dataResponse = fgets($smtp, 512);
    $smtpDebug[] = 'DATA: ' . trim($dataResponse);

    if (substr($dataResponse, 0, 3) !== '250') {
        throw new Exception("Serveur Hostinger a refusé l'envoi : " . trim($dataResponse));
    }

    $smtpSend("QUIT", 221);
    fclose($smtp);

    $emailSent = true;

} catch (Exception $e) {
    $emailError = $e->getMessage();
    error_log('BOS SMTP Error: ' . $emailError);

    // Tentative de fallback via PHP native mail()
    try {
        $nativeHeaders  = "MIME-Version: 1.0\r\n";
        $nativeHeaders .= "Content-Type: text/html; charset=UTF-8\r\n";
        $nativeHeaders .= "From: JHL Business OS <contact@jhl.ma>\r\n";
        $nativeHeaders .= "Reply-To: {$email}\r\n";
        $nativeHeaders .= "X-Mailer: PHP/" . phpversion() . "\r\n";

        $fallbackSent = @mail('contact@jhl.ma', $subject, $htmlMessage, $nativeHeaders);
        if ($fallbackSent) {
            $emailSent = true;
            $emailError = null;
        }
    } catch (Exception $mailEx) {
        // Fallback également échoué
    }
}

// Log de diagnostic si échec
if (!$emailSent && $emailError) {
    @file_put_contents(
        __DIR__ . '/business-os-mail-debug.log',
        '[' . date('Y-m-d H:i:s') . '] Échec envoi email lead #' . $newLead['id'] . ' (' . $email . ') : ' . $emailError . "\n",
        FILE_APPEND
    );
}

// ============================================
// RÉPONSE JSON (Toujours succès car sauvegardé dans leads.json)
// ============================================
echo json_encode([
    'success'     => true,
    'message'     => 'Votre demande a bien été enregistrée avec succès. Notre équipe vous contactera dans les 24h.',
    'email_sent'  => $emailSent,
    'email_error' => $emailError,
    'saved'       => true,
    'id'          => $newLead['id']
]);
